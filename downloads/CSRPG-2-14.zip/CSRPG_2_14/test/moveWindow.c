#include<windows.h>
#include<stdio.h>
void titleAndSize(void){     
    COORD bufSize = {50,25}; 
    SMALL_RECT SR = {0,0,49,24};
    SetConsoleWindowInfo(GetStdHandle(STD_OUTPUT_HANDLE),1,&SR);  //�]�w������m     
    SetConsoleScreenBufferSize(GetStdHandle(STD_OUTPUT_HANDLE),bufSize); //�]�w�w�İϤj�p
    
    //�g�J���D �]����|�X�{�ýX...�^ 
    char a[] = "NCTU Adventure";
    WCHAR wsz[50];
    swprintf(wsz,L"%S",a);
    LPCWSTR p = wsz; 
    SetConsoleTitleW(p);
}
int main(void){
    /****** ���}�]�� ******/
    MCI_OPEN_PARMS OpenParms;
    OpenParms.lpstrDeviceType = (LPCSTR) MCI_DEVTYPE_SEQUENCER;//MIDI����
    OpenParms.lpstrElementName = (LPCSTR) "guy.mid";
    OpenParms.wDeviceID = 0;
    mciSendCommand(NULL, MCI_OPEN, MCI_WAIT | MCI_OPEN_TYPE | MCI_OPEN_TYPE_ID | MCI_OPEN_ELEMENT,(DWORD)(LPVOID)&OpenParms);
    
    
    
    
    
    titleAndSize();
    getchar();
    return 0;
}
