#include<stdio.h>
#include<conio.h>
#include<math.h>
#include<string.h>
#include<ctype.h>
#include<windows.h>
#include"def.h"
/*
void chat(int,int,int,int,char*);  //��ܮ�v12 gg������  �b�Υ�������!!
     chat(x�y��,y�y��,���e�e,���e��,�˦�,npc�W�r,���e,�^��)
     �˦��� CHAT,INPUT,CHOOSE �Y��CHAT "�^��"�i�]NULL 
     �Y�Lnpc�W�r�г]NULL �Y�� �h"���e"�������Dconst�B�hstrlen(npc)+6
     �Y��CHOOSE "�^��" ���ﶵ cc�����ض}�Y 
*/
/****** chat ******/
int cchoose(int x,int y,int lw,int row_down,const char choose[]);
void SetCursorVisible(BOOL,DWORD);  //����Ьݤ���
void gotoxy(const int,const int);  //���ʴ��

int cchoose(int x,int y,int lw,int row_down,const char choose[])
{
    SetCursorVisible(FALSE,100); lw--; //���زŸ� 
    int i, j, ch=0, index=1, key=-1, item, cc=0;
    for(i=0;i<strlen(choose);i+=2){     //��cc 
        if(choose[i]=='c'&&choose[i+1]=='c') cc++;
    } //�ʺA�t�m���� 
    char *pitem, *ptok; WORD *pcolor; 
    pitem=(char*)malloc((strlen(choose)+2)*sizeof(char));
    pcolor=(WORD*)malloc(cc*sizeof(WORD));
    memset(pcolor,GRAY,cc);//��l�C�� 
    while(1!=2){
        strcpy(pitem,choose);//�ƥ�choose 
        ptok=strtok(pitem,"cc"); //�� 
        if(key==-1||key=='i'){  //�W 
            *(pcolor+index)=GRAY;
            index--;
            if(index<0) index=cc-1;
            *(pcolor+index)=128;
        }
        else if(key=='k'){    //�U 
            *(pcolor+index)=GRAY;
            index++;
            if(index>cc-1) index=0;
            *(pcolor+index)=128;
        }
        else if(key=='f') break; //�T�{ 
        for(i=1,item=0,ch=0;i<=row_down;i++)
        {
            setcolor(*(pcolor+item));
            for(j=2;j<=lw-3;j++){
                gotoxy(x+1,y+i); //���زŸ� 
                if(ch==0) printf("�E");
                if(ch!=strlen(ptok)){ 
                    gotoxy(x+j,y+i);
                    printf("%c%c",*(ptok+ch),*(ptok+ch+1));
                    ch+=2;
                }
                else{ //�U�@�� 
                    setcolor(*(pcolor+(++item)));
                    ptok=strtok(NULL,"cc");
                    ch=0; printf("\n");
                    break;
                }
            }
        }key=tolower(getch());
    }free(pcolor); free(pitem);setcolor(GRAY);
    return index;
}
int chat(int x,int y,const int w,const int h,
         const int type,const char npc[],const char content[],char reply[]){
    SetCursorVisible(TRUE,25);
    int i, j, lencnt, lennpc, speed=30;
    int lw, lh, row_up=1,row_down=1, column, ch=0, page;
    char *pcontent; //npc�� 
    lennpc=npc?strlen(npc):0;//�ʺA�t�m���e 
    pcontent=(char*)malloc((lennpc+strlen(content)+7)*sizeof(char));
    strcpy(pcontent,content);
    if(npc!=NULL){ //���W�r���W�h 
    memmove(pcontent+lennpc+6,content,strlen(content)+1);
    memmove(pcontent,npc,lennpc);
    memmove(pcontent+lennpc,"���Ggg",6);
    }//���e���� 
    lencnt=strlen(pcontent);
    //��CHOICE��� 
    if(type==CHOOSE){
        for(i=0,column=2;i<strlen(reply);i+=2){
            if(i!=0&&((reply[i]=='c'&&reply[i+1]=='c')||column==w)){
                row_down++; column=2;
                if(column!=w) column--;
            }column++;
        }    
    }//�ƹ�ܦ�� 
    for(i=0,column=0;i<lencnt;i+=2){
        if((*(pcontent+i)=='g'&&*(pcontent+i+1)=='g')||column==w){
            row_up++; column=0;
            if(*(pcontent+i)=='g'&&*(pcontent+i+1)=='g') column--;
        }column++;
    }//�[�خت��e 
    lw=w+3; lh=h+2;
    if(type==CHOOSE) lh+=row_down+1;  //�O��� 
    else if(type==INPUT) lh+=2;  //�O��J�[��� 
    //�P�_���S���W�L���� 
    if(lw>SCR_W-x+1)
        x=SCR_W-lw+1;
    if(lh>SCR_H-y+1)
        y=SCR_H-lh+1;
    //�e�~��
    gotoxy(x,y);
    printf("��");
    for(i=2;i<lw;i++)
        printf("��");
    printf("��");
    gotoxy(x,y+lh-1);
    printf("��");
    for(i=2;i<lw;i++)
        printf("��");
    printf("��");
    for(i=y+1;i<y+lh-1;i++){
        gotoxy(x,i);
        printf("��");
    }
    for(i=y+1;i<y+lh-1;i++){
        gotoxy(x+lw-1,i);
        printf("��");
    }///�M�U�� 
    if(type==INPUT||type==CHOOSE){
        gotoxy(x+1,y+lh-2-row_down);
        for(i=2;i<lw;i++)
            printf("%s",type==INPUT?"__":"--");
        for(j=0;j<row_down;j++){ 
            gotoxy(x+1,y+lh-1-row_down+j);
            for(i=2;i<lw;i++)
                printf("�@");
        }
    }//�[���|��J���e 
    if(type==INPUT) lh-=row_down+1;
    else if(type==CHOOSE) lh-=row_down+1;
    //�M���w�İ� 
    FlushConsoleInputBuffer(GetStdHandle(STD_INPUT_HANDLE));
    //��ܤ��e
    for(page=(int)ceil((float)row_up/(lh-2));page>0;page--){
        for(i=1;i<=lh-2;i++){//�M��
            gotoxy(x+1,y+i);
            for(j=1;j<=lw-2;j++) 
                printf("�@");
        }//���e 
        for(i=1;i<=lh-2;i++){
            for(j=1;j<=lw-3;j++){
                if(*(pcontent+ch)=='g'&&*(pcontent+ch+1)=='g'){//�Jgg���� 
                    ch+=2; break;
                }
                else if(ch!=lencnt){ 
                    gotoxy(x+j,y+i);
                    printf("%c%c",*(pcontent+ch),*(pcontent+ch+1));//�ڤ��o���� �o��b�ӯ��F= = 
                    Sleep(speed); ch+=2;
                }if(kbhit()) {speed=0; getch();}
            }
        } //�̫�@���F 
        if(page==1){
            if(type==INPUT){
                gotoxy(x+1,y+lh);
                gets(reply);
                break;
            }else if(type==CHOOSE){
                free(pcontent);
                return cchoose(x,y+lh-1,lw,row_down,reply);
            }
        }getch();
    }SetCursorVisible(FALSE,100);
    free(pcontent);
}
