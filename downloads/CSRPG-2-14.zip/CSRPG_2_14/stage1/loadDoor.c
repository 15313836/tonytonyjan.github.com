#include<stdio.h>
#include<string.h>
#include<windows.h>

/****** Door���c ******/
typedef struct{
    int x,y,width,hight,playerX,playerY;
    char directName[50];
}Door; 
/****** Map�a�ϵ��c ******/
typedef struct{
    int x,y;
    MapState state;
    MapState prestate;
    int color;
    char body[3];
}Map;

int doorNum;
Door *door;
int ifIndexNumOf2(int);
void setDoor(char*);

int main(void){
    setDoor("door.txt");
    getchar();
    return 0;
}

/****** �P�_n�O�_�O2������]�u�Φbprepare�^ ******/
int ifIndexNumOf2(int n){
    int i,count = 0;
    for(i=0;i<32;i++){
        if(n<0) count++;
        n = n<<1;
    }
    return count==1?1:0;
}

/****** prepare ******/
void setDoor(char* filename){   
    /****** Door�w�] ******/
    //freeDoorMomery
    int i;  //i�O�j��M��
    free(door);
    //Ūdoor.txt�ɡB�p��door�ơB�t�m�@�~    
    char s[200]; //�e��
    Door defDoor = {0};  //�ΨӪ�l�ƩҦ�npc 
    FILE* fp = fopen(filename,"r");
    doorNum=-1;
    while(fgets(s,3,fp)!=0){
        if(strcmp(s,"ff")==0){  //�a�ϩҦb��Ƨ� 
            printf("\n");
            doorNum++;
            if(doorNum+1==1) door = (Door*)malloc(sizeof(Door));  //�Ĥ@�������@�Ӧ�m
            if(ifIndexNumOf2(doorNum)) door = (Door*)realloc(door,sizeof(Door)*(doorNum+1)*2);  //�p�G�Ŧ줣���A�N���X�⭿����m
            door[doorNum] = defDoor;
            fgets(s,sizeof(door[doorNum].directName),fp);
            if(*(s+strlen(s)-1)=='\n') *(s+strlen(s)-1) = '\0'  ;  //�h��'/n' 
            strncpy(door[doorNum].directName,s,sizeof(door[doorNum].directName));
            printf("door[%d].directName=%s\n",doorNum,door[doorNum].directName);
        }else if(strcmp(s,"xx")==0){  //x�y�� 
            fgets(s,sizeof(door[doorNum].x),fp);
            door[doorNum].x = atol(s);
            printf("door[%d].x=%d\n",doorNum,door[doorNum].x);
        }else if(strcmp(s,"yy")==0){  //y�y�� 
            fgets(s,sizeof(door[doorNum].y),fp);
            door[doorNum].y = atol(s);
            printf("door[%d].y=%d\n",doorNum,door[doorNum].y);
        }else if(strcmp(s,"ww")==0){  //width 
            fgets(s,sizeof(door[doorNum].width),fp);
            door[doorNum].width = atol(s);
            printf("door[%d].width=%d\n",doorNum,door[doorNum].width);
        }else if(strcmp(s,"hh")==0){  //hight 
            fgets(s,sizeof(door[doorNum].hight),fp);
            door[doorNum].hight = atol(s);
            printf("door[%d].hight=%d\n",doorNum,door[doorNum].hight);
        }else if(strcmp(s,"px")==0){  //px�y�� 
            fgets(s,sizeof(door[doorNum].playerX),fp);
            door[doorNum].playerX = atol(s);
            printf("door[%d].playerX=%d\n",doorNum,door[doorNum].playerX);
        }else if(strcmp(s,"py")==0){  //py�y�� 
            fgets(s,sizeof(door[doorNum].playerY),fp);
            door[doorNum].playerY = atol(s);
            printf("door[%d].playerY=%d\n",doorNum,door[doorNum].playerY);
        }
    }
    doorNum++;
    fclose(fp);  
}
