#include<stdio.h>
#include<windows.h>

int main(void){

}
