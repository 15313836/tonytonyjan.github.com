#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<conio.h>
#include<windows.h>
#include"def.h"
int setMenu(void);  //�}�l���   
int chat(int,int,const int,const int,const int,const char*,const char*,char*);
void gotoxy(const int,const int);  //���ʴ��
void SetCursorVisible(BOOL,DWORD);  //����Ьݤ��� 
void start(void)
{
    setcolor(GREEN+BRIGHT); 
    chat(SCR_W/2-4,SCR_H/2-2,7,3,CHAT,NULL,"��V�G������T�{�G��gg���}�G�Ӣ���",NULL);
    setcolor(GRAY);
    SetCursorVisible(FALSE,100);
    FILE *pabout; char* pfabout;int choice=-1;
    pfabout=(char*)malloc(100*sizeof(char));
    do{
        choice=setMenu();
        switch(choice){
            case 3:
                exit(0);
            case 2:
                pabout=fopen("about.txt","r");
                fgets(pfabout,100,pabout);
                fclose(pabout);
                setcolor(GREEN+BRIGHT);
                chat(SCR_W/2-7,SCR_H/2-2,15,6,CHAT,NULL,pfabout,NULL);
                setcolor(GRAY);
        }
    }while(choice!=0);
    free(pfabout);
    
}
/****** setMenu ******/
int setMenu(void)
{
    WORD color[MENU_SIZE]={21,7,7,7};
    char* pwelcome; int n=1,x=-1, i, j;
    FILE *pfile;
    pwelcome=(char*)malloc(100*sizeof(char));
    for(i=1;i<=SCR_H;i++) //�M�� 
    {
        for(j=1;j<=SCR_W;j++)
        {
            gotoxy(j,i);
            printf("�@");
        }
    }
    i=1;//�w��e�� 
    pfile=fopen("welcome.txt","r");
    setcolor(GREEN+BLUE);
    while(!feof(pfile))
    {
        gotoxy(7,i++);
        fgets(pwelcome,100,pfile);
        printf("%s",pwelcome);
    }setcolor(GRAY);
    while(1!=2)
    {
        if(x==-1||x=='i')
        {
            color[n]=GRAY;
            n--;
            if(n<0) n=MENU_SIZE-1;
            color[n]=BACKGROUND_BLUE+GRAY;
        }
        else if(x=='k')
        {
            color[n]=GRAY;
            n++;
            if(n>MENU_SIZE-1) n=0;
            color[n]=BACKGROUND_BLUE+GRAY;
        }
        gotoxy(SCR_W/2-6,SCR_H-4);
        setcolor(color[0]);
        printf("�@(S)tart  �i ����}�l �i�@");
        gotoxy(SCR_W/2-6,SCR_H-3);
        setcolor(color[1]);
        printf("�@(O)ption �k �ϥΪ̳]�w �k�@");
        gotoxy(SCR_W/2-6,SCR_H-2);
        setcolor(color[2]);
        printf("�@(A)bout  �b ���d�s�@�s �b  ");
        gotoxy(SCR_W/2-6,SCR_H-1);
        setcolor(color[3]);
        printf("�@(E)xit   �_ �U���A�|�a �_�@");
        x=tolower(getch());
        if(x=='f') return n;
        else if(x==ESC)  exit(0);
        else if(x=='s')  return 0;
        else if(x=='o')  return 1;
        else if(x=='a')  return 2;
        else if(x=='e')  return 3;
    }
} 
