#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include <windows.h>
#include"def.h"
#define LABEL_SIZE 4
void gotoxy(const int,const int);  //���ʴ��
void menu(void)
{
    int i, j, index=-4;
    int x=1, y=1, lw=SCR_W, lh=SCR_H, key='l';
    char *plabel[5]={" BIOS "," RAM  "," Quest","  Map "," Code ",};
    //�e�~��
    gotoxy(x,y);
    printf("��");
    for(i=2;i<lw;i++)
        printf("��");
    printf("��");
    gotoxy(x,y+lh-1);
    printf("��");
    for(i=2;i<lw;i++)
        printf("��");
    printf("��");
    for(i=y+1;i<y+lh-1;i++){
        gotoxy(x,i);
        printf("��");
    }
    for(i=y+1;i<y+lh-1;i++){
        gotoxy(x+lw-1,i);
        printf("��");
    }//�e����
    gotoxy(x+1,y+lh-2);
    printf("��");
    for(i=3;i<lw-1;i++)
        printf("�w");
    printf("��");
    for(i=y+4;i<y+lh-2;i++){
        gotoxy(x+1,i);
        printf("�x");
    }
    for(i=y+4;i<y+lh-2;i++){
        gotoxy(x+lw-2,i);
        printf("�x");
    }
    
    while(1!=2){
        if(key==ESC||key==VK_SPACE||key==VK_RETURN) return;
        else if(key=='l') index+=4;
        else if(key=='j') index-=4;
        else {key=getch(); continue;}
        if(index>4*LABEL_SIZE) index=0;
        else if(index<0) index=4*LABEL_SIZE;
        gotoxy(x+1,y+3);
        printf("�~");
        for(i=3;i<lw-1;i++)
            printf("�w");
        printf("��");
        setcolor(8);
        gotoxy(x+1,y+1);
        printf("�~�w�w�w���w�w�w���w�w�w���w�w�w���w�w�w��");
        for(i=4;i<=4*LABEL_SIZE;i+=4){
            gotoxy(x+1+i,y+1);
            if(i<index) printf("�~");
            else printf("��");
        }
        gotoxy(x+1,y+2);
        printf("�x");
        for(i=0;i<=4*LABEL_SIZE;i+=4)
            printf("%s�x",plabel[i/4]);
        setcolor(GRAY);
        gotoxy(x+1+index,y+1);
        printf("�~�w�w�w��");
        gotoxy(x+1+index,y+2);
        printf("�x%s�x",plabel[index/4]);
        gotoxy(x+1+index,y+3);
        switch(index/4){
            case 0:
                printf("�x�@�@�@�|");
                break;
            case LABEL_SIZE:
                printf("�}�@�@�@�x");
                break;
            default:
                printf("�}�@�@�@�|");
        }
        for(i=4;i<=lh-3;i++){//�M��
            gotoxy(x+2,y+i);
            for(j=1;j<=lw-4;j++) 
                printf("�@");
        }
        key=tolower(getch());
    }
}
