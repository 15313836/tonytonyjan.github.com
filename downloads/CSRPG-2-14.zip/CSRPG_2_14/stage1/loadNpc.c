#include<stdio.h>
#include<string.h>
#include<windows.h>

/****** MapState�a�Ϫ��A�C�| ******/
typedef enum{DEFAULT,BLOCK,GRASS,DOOR,TONY,NPC}MapState;
/****** PState���a���A�C�| ******/ 
typedef enum{STOP,UP,DOWN,LEFT,RIGHT,EVENT}PState;
/****** ���ȵ��c ******/
typedef struct{
    int ifClear; //�O�_���\
    char content[2][100]; //��npc���ܥ� content[0]�O���ȧ������e content�O���ȧ�������
}Mission; 
/****** Npc���c ******/
typedef struct{
    int x,y,prex,prey,hp,talkTimes,speed,talkNum,randTalkNum;
    Mission mission;
    char body[3];
    char name[9]; 
    char **talk;
    char **randTalk;
    int state; 
}Npc;
/****** Door���c ******/
typedef struct{
    int x,y,width,hight,playerX,playerY;
    char mapFileName[50],npcFileName[50],doorFileName[50];
}Door; 
/****** Map�a�ϵ��c ******/
typedef struct{
    int x,y;
    MapState state;
    MapState prestate;
    int color;
    char body[3];
}Map;

int npcNum;
Npc *npc;
int ifIndexNumOf2(int);
void prepare(char*);

int main(void){
    prepare("npc.txt");
    getchar();
    return 0;
}

/****** �P�_n�O�_�O2������]�u�Φbprepare�^ ******/
int ifIndexNumOf2(int n){
    int i,count = 0;
    for(i=0;i<32;i++){
        if(n<0) count++;
        n = n<<1;
    }
    return count==1?1:0;
}

/****** prepare ******/
void prepare(char* filename){   
    /****** Npc�w�] ******/
    //freeNpcMomery
    int i,t,r;  //i�O�j��M�� t,r�ΨӼ�npt.txt��tt�Mrr 
    for(i=0;i<npcNum;i++){
        for(t=0;t<npc[i].talkNum;t++) free(npc[i].talk[t]);
        free(npc[i].talk);
        for(r=0;r<npc[i].randTalkNum;r++) free(npc[i].randTalk[r]);       
        free(npc[i].randTalk);
    }
    free(npc);
    //Ūnpc.txt�ɡB�p��npc�ơB�t�m�@�~    
    char s[200]; //�e��
    Npc defNpc = {0};  //�ΨӪ�l�ƩҦ�npc 
    FILE* fp = fopen(filename,"r");
    npcNum=-1;
    while(fgets(s,3,fp)!=0){
        if(strcmp(s,"nn")==0){  //�W�r 
            printf("\n");
            npcNum++;
            t=r=-1;
            if(npcNum+1==1) npc = (Npc*)malloc(sizeof(Npc));  //�Ĥ@�������@�Ӧ�m
            if(ifIndexNumOf2(npcNum)) npc = (Npc*)realloc(npc,sizeof(Npc)*(npcNum+1)*2);  //�p�G�Ŧ줣���A�N���X�⭿����m
            npc[npcNum] = defNpc;
            fgets(s,sizeof(npc[npcNum].name),fp);
            if(*(s+strlen(s)-1)=='\n') *(s+strlen(s)-1) = '\0'  ;  //�h��'/n' 
            strncpy(npc[npcNum].name,s,sizeof(npc[npcNum].name));
            printf("npc[%d].name=%s\n",npcNum,npc[npcNum].name);
        }else if(strcmp(s,"bb")==0){  //����
            fgets(s,sizeof(npc[npcNum].body),fp);
            strncpy(npc[npcNum].body,s,sizeof(npc[npcNum].body));
            printf("npc[%d].body=%s\n",npcNum,npc[npcNum].body);
        }else if(strcmp(s,"ss")==0){  //�t��
            fgets(s,3,fp);
            npc[npcNum].speed = atol(s);
            printf("npc[%d].speed=%d\n",npcNum,npc[npcNum].speed);
        }else if(strcmp(s,"tt")==0){  //talk
            t++;
            if(t+1==1) npc[npcNum].talk = (char**)malloc(sizeof(char*));  //�Ĥ@�����t�m�@�Ӧ�m 
            if(ifIndexNumOf2(t)) npc[npcNum].talk = (char**)realloc(npc[npcNum].talk,sizeof(char*)*(t+1)*2); //�t�m�y�l�A�����ɦ۰ʫ��X�⭿���Ŷ�
            fgets(s,sizeof(s),fp);
            if(*(s+strlen(s)-1)=='\n') *(s+strlen(s)-1) = '\0'  ;  //�h��'/n'
            npc[npcNum].talk[t] = (char*)malloc(sizeof(char)*(strlen(s)+1));
            strncpy(npc[npcNum].talk[t],s,strlen(s)+1);
            npc[npcNum].talkNum = t+1;
            printf("npc[%d].talk[%d]=%s\n",npcNum,t,npc[npcNum].talk[t]);
        }else if(strcmp(s,"rr")==0){  //randTalk 
            r++;
            if(r+1==1) npc[npcNum].randTalk = (char**)malloc(sizeof(char*));
            if(ifIndexNumOf2(r)) npc[npcNum].randTalk = (char**)realloc(npc[npcNum].randTalk,sizeof(char*)*(r+1)*2); //�t�m�y�l�A�����ɦ۰ʫ��X�⭿���Ŷ�
            fgets(s,sizeof(s),fp);
            if(*(s+strlen(s)-1)=='\n') *(s+strlen(s)-1) = '\0'  ;  //�h��'/n'
            npc[npcNum].randTalk[r] = (char*)malloc(sizeof(char)*(strlen(s)+1));
            strncpy(npc[npcNum].randTalk[r],s,strlen(s)+1);
            npc[npcNum].randTalkNum = r+1;
            printf("npc[%d].randTalk[%d]=%s\n",npcNum,r,npc[npcNum].randTalk[r]);            
        }
    }
    npcNum++;
    fclose(fp);  
}
