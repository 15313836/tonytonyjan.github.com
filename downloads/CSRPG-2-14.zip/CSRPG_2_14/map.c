/* �a�� */ 
/*
void setScr(int x,int y,int w,int h,int color);  //�~�س]�w
void flash(void);  //��s�ù� 
void setMap(char*);  //�a�ϳ]�w
*/ 
#include"initial.h"
#include<stdio.h>
/****** setScr ******/
void setScr(int x,int y,int w,int h,int color){
    int i;
    setcolor(color);
    for(i=x+1;i<w+x+1;i++){
        gotoxy(i,y);
        printf("�b");  //�W��
        gotoxy(i,h+y+1);
        printf("�v");  //�U��
    }
    for(i=y+1;i<h+y+1;i++){  
        gotoxy(x,i);
        printf("�y");  //����
        gotoxy(w+x+1,i);
        printf("�j");  //�k��
    }
    setcolor(GRAY);
}

/****** setMap ******/
void setMap(char* filename){ 
    //Ū���a���ɨüЩw�D����m 
    FILE *fp;
    fp = fopen(filename,"r");
    int x = 0,y=0,i;
    char c;
    while(c!=EOF){
        while(1==1){
            c = getc(fp);
            if(c == 10 | c == EOF) break;
            map[x][y].body[0] = c;
            c = getc(fp);
            if(c == 10) break;
            map[x][y].body[1] = c;
            if(strcmp(map[x][y].body,"�w")==0 || strcmp(map[x][y].body,"�x")==0
            || strcmp(map[x][y].body,"�z")==0 || strcmp(map[x][y].body,"�{")==0
            || strcmp(map[x][y].body,"�|")==0 || strcmp(map[x][y].body,"�}")==0
            || strcmp(map[x][y].body,"�q")==0 || strcmp(map[x][y].body,"�u")==0
            || strcmp(map[x][y].body,"�s")==0 || strcmp(map[x][y].body,"�r")==0
            || strcmp(map[x][y].body,"�t")==0)
            {
                map[x][y].state = map[x][y].prestate = BLOCK;
                strcpy(map[x][y].body,"��");
            }else if(strcmp(map[x][y].body,"��")==0){
                map[x][y].state = map[x][y].prestate = GRASS;
            }else if(strcmp(map[x][y].body,"��")==0){
                tony.x = x;
                tony.y = y;
                tony.speed = 1;
                strcpy(map[x][y].body,"  ");
                map[x][y].state=TONY;
            }else map[x][y].state = DEFAULT;
            //�ЩwNpc��m
            for(i=0;i<NPC_NUM;i++){
                if(strcmp(map[x][y].body,npc[i].body)==0){
                    npc[i].x = npc[i].prex = x;
                    npc[i].y = npc[i].prey = y;
                    npc[i].speed = 10; //npc���t�� 
                    npc[i].ifTalked = 0;
                    map[x][y].state = NPC;
                }
            }
            x++;
        }
        mapWidth = x;
        x=0;
        y++;
        mapHight = y;
    }
    //�p��scrFocus
    if(abs(tony.x-mapWidth/2)< (mapWidth-SCR_W)/2){
        scrFocus_x = tony.x-SCR_W/2-1;
    }
    if(abs(tony.y-mapHight/2)< (mapHight-SCR_H)/2){
        scrFocus_y = tony.y-SCR_H/2-1; 
    }
}
/****** prepare ******/
void prepare(char* filename){
    //�D���w�]
    tony.hp = 100;
    strcpy(tony.body,"��");
    tony.state = STOP;
    //Npc�w�]
    int i = 0;
    char body[3];
    char talk[100];
    FILE* fp;
    fp = fopen(filename,"r");
    while(fscanf(fp,"%s %s",body,talk)!=EOF){
        strcpy(npc[i].body,body);
        strcpy(npc[i].talk,talk);
        i++;
    }
    npcNum = i;
    fclose(fp);
}
