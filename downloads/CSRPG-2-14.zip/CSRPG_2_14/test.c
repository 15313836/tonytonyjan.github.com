#include<stdlib.h>
#include<windows.h>
#include<time.h>
#include"def.h"
extern int scrFocus_x,scrFocus_y,npcNum,doorNum;
extern Map **map;
void prepare(char*);
int chat(int,int,const int,const int,const int,const char*,const char*,char*);
/****** hitNpc ******/
/*int hitNpc(Player a,Npc* b){
    int i;
    for(i=0;i<npcNum;i++){
        if(a.x == b[i].x && a.y==b[i].y) return 1;
    }
    return 0;
}*/

/****** xyhitNpc ******/
/*int xyhitNpc(int x,int y,Npc* b){
    int i;
    for(i=0;i<npcNum;i++){
        if(x == b[i].x && y==b[i].y) return 1;
    }
    return 0;
}*/

/****** talkTest ******/
void talkTest(Player *a ,Npc b[]){
    int i; 
    srand(time(NULL));
    for(i=0;i<npcNum;i++){
        if((a->x == b[i].x && abs(a->y - b[i].y)==1) || (a->y == b[i].y && abs(a->x - b[i].x)==1)){ //�q�ܽd��G�e�ᥪ�k 
        //if(abs(a->y - b[i].y)<=1 && abs(a->x - b[i].x)<=1){  //��ܽd��G�e�ᥪ�k�[�׹﨤
            //�u���@�� 
            if(b[i].talkTimes<b[i].talkNum) chat(b[i].x-scrFocus_x+1,b[i].y-scrFocus_y+1,12,2,CHAT,b[i].name,b[i].talk[b[i].talkTimes],NULL);               
            //�H������ 
            else chat(b[i].x-scrFocus_x+1,b[i].y-scrFocus_y+1,12,2,CHAT,b[i].name,b[i].randTalk[rand()%b[i].randTalkNum],NULL);
            b[i].talkTimes++;
            Sleep(150);
        }
    }
}
/****** doorTest ******/
void doorTest(Player *a,Door *b){
    int i;
    for(i=0;i<doorNum;i++){
        if(a->x>=b[i].x && a->x<b[i].x+b[i].width && a->y>=b[i].y && a->y<b[i].y+b[i].hight){
            int x = b[i].playerX, y = b[i].playerY;;
            prepare(b[i].directName);
            map[a->x][a->y].state = DEFAULT;
            a->x = x;
            a->y = y;
            break;
        }
    }
}
