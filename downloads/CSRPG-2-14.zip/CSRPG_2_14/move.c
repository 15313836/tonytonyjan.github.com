#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include<windows.h>
#include"def.h"
extern Player *playerp;
extern Map **map;
extern int mapWidth,mapHight;
extern int scrFocus_x,scrFocus_y;
extern int npcNum;  //�@���h��npc
extern Npc *npc;
extern Door *door;
extern int tclock;  //����
void control(void);  //��ť��L
void calculate(void);  //�p��C�ӪF�誺���p
void flash(void);  //��s�ù� 
void gotoxy(const int,const int);  //���ʴ��
void talkTest(Player *a ,Npc b[]);  //�O�_�i�J��ܽd�� 
void doorTest(Player *a,Door *b);
void prepare(char*);  //�ǳƨ�� 
void setMap(char*); //���J�a�� 
void menu(void);
void move(void)
{
    flash();
    control();
    calculate();
}
/****** flash ******/
void flash(void){
    int x,y,i,j,k,w=SCR_W+1, h=SCR_H+1, sign = 1;
    if(playerp->state == UP || playerp->state == DOWN){w=SCR_H+1; h=SCR_W+1;}
    for(i=1;i<w;i++){
        for(j=1;j<h;j++){
            if(playerp->state == UP || playerp->state == DOWN){x=j; y=i;}
            else{x=i; y=j;}
            gotoxy(x,y);            
            switch(map[x+scrFocus_x][y+scrFocus_y].state){
                case DEFAULT:
                     printf("%s",map[x+scrFocus_x][y+scrFocus_y].body);
                    break;
                case BLOCK:
                    setcolor(RED);                                   
                    printf("�i");
                    setcolor(GRAY);
                    break;
                case GRASS:
                    setcolor(GREEN);                                  
                    printf("��");
                    setcolor(GRAY);
                    break;
                case LAMP:
                    setcolor(GREEN+RED+BRIGHT);                                  
                    printf("�Z");
                    setcolor(GRAY);
                    break;                    
                case TONY:  //���Tony
                    setcolor(BLUE+GREEN+BRIGHT);                                    
                    printf("%s",playerp->body);
                    setcolor(GRAY);  
                    break;
                case NPC:  //���Npc            
                    setcolor(GREEN+BRIGHT);
                    for(k=0;k<npcNum;k++){
                    if(x+scrFocus_x == npc[k].x && y+scrFocus_y==npc[k].y)
                            printf("%s",npc[k].body);
                    }
                    setcolor(GRAY);                     
                    break;
            }            

        }
    }
}
/****** control ******/
void control(void){
    if(GetKeyState(ESC)<0) exit(0);
    else if(GetKeyState(VK_RETURN)<0) menu();
    if(GetKeyState('I')<0)playerp->state = UP;
    else if(GetKeyState('K')<0)playerp->state = DOWN;
    else if(GetKeyState('J')<0)playerp->state = LEFT;
    else if(GetKeyState('L')<0)playerp->state = RIGHT;
    else if(GetKeyState('F')<0)playerp->state = EVENT;
    else playerp->state = STOP;
}
/****** calculate ******/
void calculate(void){
    int i;
    //�H�U�O�D��
    if(tclock%playerp->speed == 0){  //�t��
        //����
        if(playerp->state == UP) {map[playerp->x][playerp->y].state=map[playerp->x][playerp->y].prestate; playerp->y--;}
        else if(playerp->state == DOWN) {map[playerp->x][playerp->y].state=map[playerp->x][playerp->y].prestate; playerp->y++;}
        else if(playerp->state == LEFT) {map[playerp->x][playerp->y].state=map[playerp->x][playerp->y].prestate; playerp->x--;}
        else if(playerp->state == RIGHT) {map[playerp->x][playerp->y].state=map[playerp->x][playerp->y].prestate; playerp->x++;}
        else if(playerp->state == EVENT) talkTest(playerp,npc);
        //���ʹL��P�_�O�_����F��
        if(map[playerp->x][playerp->y].state==BLOCK || map[playerp->x][playerp->y].state==NPC || map[playerp->x][playerp->y].state==LAMP){
            if(playerp->state == UP) playerp->y++; 
            else if(playerp->state == DOWN) playerp->y--;
            else if(playerp->state == LEFT) playerp->x++;
            else if(playerp->state == RIGHT) playerp->x--;
        }
        doorTest(playerp,door);  //�� 
        map[playerp->x][playerp->y].state=TONY;
        //�p��scrFocus
        if(abs(playerp->x-mapWidth/2)< (mapWidth-SCR_W)/2) scrFocus_x = playerp->x-SCR_W/2-1;
        else{
            if(playerp->x<mapWidth/2) scrFocus_x = 0;
            else if(playerp->x>mapWidth-SCR_W/2) scrFocus_x = mapWidth-SCR_W-2;
        }
         
        if(abs(playerp->y-mapHight/2)< (mapHight-SCR_H)/2) scrFocus_y = playerp->y-SCR_H/2-1; 
        else{
            if(playerp->y<mapHight/2) scrFocus_y = 0;
            else if(playerp->y>mapHight-SCR_H/2) scrFocus_y = mapHight-SCR_H-2;
        } 
    }
    //�H�U�Onpc 
    srand(time(0));
    for(i=0;i<npcNum;i++){
        if(tclock%npc[i].speed == 0){       
            if(tclock%(10*npc[i].speed)==0) npc[i].state = rand()%5;  //�C���B�����A�@�� 
            //����
            if(npc[i].state == UP) {map[npc[i].x][npc[i].y].state=map[npc[i].x][npc[i].y].prestate; npc[i].y--;}
            else if(npc[i].state == DOWN) {map[npc[i].x][npc[i].y].state=map[npc[i].x][npc[i].y].prestate; npc[i].y++;}
            else if(npc[i].state == LEFT) {map[npc[i].x][npc[i].y].state=map[npc[i].x][npc[i].y].prestate; npc[i].x--;}
            else if(npc[i].state == RIGHT) {map[npc[i].x][npc[i].y].state=map[npc[i].x][npc[i].y].prestate; npc[i].x++;}
            //���ʹL��P�_�O�_����F��ζW�X�����d�� 
            if(map[npc[i].x][npc[i].y].state == BLOCK || map[npc[i].x][npc[i].y].state == LAMP || map[npc[i].x][npc[i].y].state == TONY || map[npc[i].x][npc[i].y].state == NPC || abs(npc[i].x-npc[i].prex)>2 || abs(npc[i].y-npc[i].prey) >2){
                if(npc[i].state == UP) npc[i].y++;
                else if(npc[i].state == DOWN) npc[i].y--;
                else if(npc[i].state == LEFT) npc[i].x++;
                else if(npc[i].state == RIGHT) npc[i].x--;
                npc[i].state = STOP;  //����F�谱�U�� 
            }
            map[npc[i].x][npc[i].y].state = NPC;
        }
    }
}
