#include <windows.h>
/****** SetCursorVisible ******/
void SetCursorVisible(BOOL _bVisible,DWORD _dwSize){
  CONSOLE_CURSOR_INFO CCI;
  CCI.bVisible = _bVisible;
  CCI.dwSize = _dwSize;  //�]��Ъ��A 
  SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE),&CCI);
}
/****** gotoxy ******/
void gotoxy(const int x,const int y){
  COORD point;
  point.X=2*x;
  point.Y=y;  //�]���
  SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),point);
}
