#include"def.h"
#include<string.h>
#include<stdio.h>
#include<windows.h>
extern Player *playerp;
extern Npc *npc;
extern Door *door; 
extern int npcNum;  //�@���h��npc
extern int doorNum;
extern Map **map;
extern int mapWidth,mapHight;
extern int scrFocus_x,scrFocus_y;
void gotoxy(const int,const int);  //���ʴ��
void SetCursorVisible(BOOL,DWORD);  //����Ьݤ���

/****** �P�_n�O�_�O2������]�u�Φbprepare�^ ******/
int ifIndexNumOf2(int n){
    int i,count = 0;
    for(i=0;i<32;i++){
        if(n<0) count++;
        n = n<<1;
    }
    return count==1?1:0;
}
/****** setPlayer ******/
void setPlayer(char* filename){
    char s[200];
    FILE* fp;
    fp = fopen(filename,"r");
    while(fgets(s,3,fp)!=0){
        if(strcmp(s,"xx")==0){
            fgets(s,sizeof(playerp->x),fp);
            playerp->x = atol(s);
        }else if(strcmp(s,"yy")==0){
            fgets(s,sizeof(playerp->y),fp);
            playerp->y = atol(s);
        }
    }
}
/****** setNpc ******/
void setNpc(char* filename){   
    /****** Npc�w�] ******/
    //freeNpcMomery
    int i,t,r;  //i�O�j��M�� t,r�ΨӼ�npt.txt��tt�Mrr 
    for(i=0;i<npcNum;i++){
        for(t=0;t<npc[i].talkNum;t++) free(npc[i].talk[t]);
        free(npc[i].talk);
        for(r=0;r<npc[i].randTalkNum;r++) free(npc[i].randTalk[r]);       
        free(npc[i].randTalk);
    }
    free(npc);
    //Ūnpc.txt�ɡB�p��npc�ơB�t�m�@�~    
    char s[200]; //�e��
    Npc defNpc = {0};  //�ΨӪ�l�ƩҦ�npc 
    FILE* fp = fopen(filename,"r");
    npcNum=-1;
    while(fgets(s,3,fp)!=0){
        if(strcmp(s,"nn")==0){  //�W�r 
            npcNum++;
            t=r=-1;
            if(npcNum+1==1) npc = (Npc*)malloc(sizeof(Npc));  //�Ĥ@�������@�Ӧ�m
            if(ifIndexNumOf2(npcNum)) npc = (Npc*)realloc(npc,sizeof(Npc)*(npcNum+1)*2);  //�p�G�Ŧ줣���A�N���X�⭿����m
            npc[npcNum] = defNpc;
            fgets(s,sizeof(npc[npcNum].name),fp);
            if(*(s+strlen(s)-1)=='\n') *(s+strlen(s)-1) = '\0'  ;  //�h��'/n' 
            strncpy(npc[npcNum].name,s,sizeof(npc[npcNum].name));
        }else if(strcmp(s,"bb")==0){  //����
            fgets(s,sizeof(npc[npcNum].body),fp);
            strncpy(npc[npcNum].body,s,sizeof(npc[npcNum].body));
        }else if(strcmp(s,"ss")==0){  //�t��
            fgets(s,sizeof(s),fp);
            npc[npcNum].speed = atol(s);
        }else if(strcmp(s,"tt")==0){  //talk
            t++;
            if(t+1==1) npc[npcNum].talk = (char**)malloc(sizeof(char*));  //�Ĥ@�����t�m�@�Ӧ�m 
            if(ifIndexNumOf2(t)) npc[npcNum].talk = (char**)realloc(npc[npcNum].talk,sizeof(char*)*(t+1)*2); //�t�m�y�l�A�����ɦ۰ʫ��X�⭿���Ŷ�
            fgets(s,sizeof(s),fp);
            if(*(s+strlen(s)-1)=='\n') *(s+strlen(s)-1) = '\0'  ;  //�h��'/n'
            npc[npcNum].talk[t] = (char*)malloc(sizeof(char)*(strlen(s)+1));
            strncpy(npc[npcNum].talk[t],s,strlen(s)+1);
            npc[npcNum].talkNum = t+1;
        }else if(strcmp(s,"rr")==0){  //randTalk 
            r++;
            if(r+1==1) npc[npcNum].randTalk = (char**)malloc(sizeof(char*));
            if(ifIndexNumOf2(r)) npc[npcNum].randTalk = (char**)realloc(npc[npcNum].randTalk,sizeof(char*)*(r+1)*2); //�t�m�y�l�A�����ɦ۰ʫ��X�⭿���Ŷ�
            fgets(s,sizeof(s),fp);
            if(*(s+strlen(s)-1)=='\n') *(s+strlen(s)-1) = '\0'  ;  //�h��'/n'
            npc[npcNum].randTalk[r] = (char*)malloc(sizeof(char)*(strlen(s)+1));
            strncpy(npc[npcNum].randTalk[r],s,strlen(s)+1);
            npc[npcNum].randTalkNum = r+1;     
        }
    }
    npcNum++;
    fclose(fp);    
}
/****** setScr ******/
void setScr(int x,int y,int w,int h,int color){
    int i;
    setcolor(color);
    for(i=x+1;i<w+x+1;i++){
        gotoxy(i,y);
        printf("�b");  //�W��
        gotoxy(i,h+y+1);
        printf("�v");  //�U��
    }
    for(i=y+1;i<h+y+1;i++){  
        gotoxy(x,i);
        printf("�y");  //����
        gotoxy(w+x+1,i);
        printf("�j");  //�k��
    }
    setcolor(GRAY);
}
/****** setMap ******/
void setMap(char* filename){
    //freememory
    int i;
    for(i=0;i<mapWidth;i++) free(map[i]);
    free(map);     
    //�p��a�Ϥj�p 
    FILE *fp;
    fp = fopen(filename,"r");
    int x = 0,y=0;
    char s[3];  //���� 
    while(fgets(s,3,fp)!=0){
        if(s[0]==10){y++; x=0;}
        else x++;
    }
    mapWidth = x;
    mapHight = y+1;
    //�t�m�O���� 
    map = (Map**)malloc(sizeof(Map*)*mapWidth);
    for(i=0;i<mapWidth;i++) map[i] = (Map*)malloc(sizeof(Map)*mapHight);
    //�إߦa��
    fseek(fp,0,SEEK_SET);  //�ɮ׫��в������Y
    for(y=0;y<mapHight;y++){
        for(x=0;x<mapWidth;x++){
            fgets(s,3,fp);
            if(s[0]==10) fgets(s,3,fp);
            strcpy(map[x][y].body,s);
            if(strcmp(map[x][y].body,"�w")==0 || strcmp(map[x][y].body,"�x")==0
            || strcmp(map[x][y].body,"�z")==0 || strcmp(map[x][y].body,"�{")==0
            || strcmp(map[x][y].body,"�|")==0 || strcmp(map[x][y].body,"�}")==0
            || strcmp(map[x][y].body,"�q")==0 || strcmp(map[x][y].body,"�u")==0
            || strcmp(map[x][y].body,"�s")==0 || strcmp(map[x][y].body,"�r")==0
            || strcmp(map[x][y].body,"�t")==0)
            {
                map[x][y].state = map[x][y].prestate = BLOCK;
            }else if(strcmp(map[x][y].body,"��")==0){
                map[x][y].state = map[x][y].prestate = GRASS;
            }else if(strcmp(map[x][y].body,"�Z")==0){
                map[x][y].state = map[x][y].prestate = LAMP;
            }else if(strcmp(map[x][y].body,"��")==0){
                playerp->x = x;
                playerp->y = y;
                strcpy(map[x][y].body,"  ");
                map[x][y].state=TONY;
                map[x][y].prestate = DEFAULT; 
            }else map[x][y].state = map[x][y].prestate = DEFAULT;
            //�ЩwNpc��m
            for(i=0;i<npcNum;i++){
                if(strcmp(map[x][y].body,npc[i].body)==0){
                    npc[i].x = npc[i].prex = x;
                    npc[i].y = npc[i].prey = y; 
                    npc[i].talkTimes = 0;
                    strcpy(map[x][y].body,"  ");
                    map[x][y].state = NPC;
                }
            }
        }
    }
    //�p��scrFocus
    if(abs(playerp->x-mapWidth/2)< (mapWidth-SCR_W)/2) scrFocus_x = playerp->x-SCR_W/2-1;
    else{
        if(playerp->x<mapWidth/2) scrFocus_x = 0;
        else if(playerp->x>mapWidth-SCR_W/2) scrFocus_x = mapWidth-SCR_W-2;
    }
     
    if(abs(playerp->y-mapHight/2)< (mapHight-SCR_H)/2) scrFocus_y = playerp->y-SCR_H/2-1; 
    else{
        if(playerp->y<mapHight/2) scrFocus_y = 0;
        else if(playerp->y>mapHight-SCR_H/2) scrFocus_y = mapHight-SCR_H-2;
    }  
}
/****** setDoor ******/
void setDoor(char* filename){   
    /****** Door�w�] ******/
    //freeDoorMomery
    int i;  //i�O�j��M��
    free(door);
    //Ūdoor.txt�ɡB�p��door�ơB�t�m�@�~    
    char s[200]; //�e��
    Door defDoor = {0};  //�ΨӪ�l�ƩҦ�npc 
    FILE* fp = fopen(filename,"r");
    doorNum=-1;
    while(fgets(s,3,fp)!=0){
        if(strcmp(s,"ff")==0){  //�a�ϩҦb��Ƨ� 
            //printf("\n");
            doorNum++;
            if(doorNum+1==1) door = (Door*)malloc(sizeof(Door));  //�Ĥ@�������@�Ӧ�m
            if(ifIndexNumOf2(doorNum)) door = (Door*)realloc(door,sizeof(Door)*(doorNum+1)*2);  //�p�G�Ŧ줣���A�N���X�⭿����m
            door[doorNum] = defDoor;
            fgets(s,sizeof(door[doorNum].directName),fp);
            if(*(s+strlen(s)-1)=='\n') *(s+strlen(s)-1) = '\0'  ;  //�h��'/n' 
            strncpy(door[doorNum].directName,s,sizeof(door[doorNum].directName));
            //printf("door[%d].directName=%s\n",doorNum,door[doorNum].directName);
        }else if(strcmp(s,"xx")==0){  //x�y�� 
            fgets(s,sizeof(door[doorNum].x),fp);
            door[doorNum].x = atol(s);
            //printf("door[%d].x=%d\n",doorNum,door[doorNum].x);
        }else if(strcmp(s,"yy")==0){  //y�y�� 
            fgets(s,sizeof(door[doorNum].y),fp);
            door[doorNum].y = atol(s);
            //printf("door[%d].y=%d\n",doorNum,door[doorNum].y);
        }else if(strcmp(s,"ww")==0){  //width 
            fgets(s,sizeof(door[doorNum].width),fp);
            door[doorNum].width = atol(s);
            //printf("door[%d].width=%d\n",doorNum,door[doorNum].width);
        }else if(strcmp(s,"hh")==0){  //hight 
            fgets(s,sizeof(door[doorNum].hight),fp);
            door[doorNum].hight = atol(s);
            //printf("door[%d].hight=%d\n",doorNum,door[doorNum].hight);
        }else if(strcmp(s,"px")==0){  //px�y�� 
            fgets(s,sizeof(door[doorNum].playerX),fp);
            door[doorNum].playerX = atol(s);
            //printf("door[%d].playerX=%d\n",doorNum,door[doorNum].playerX);
        }else if(strcmp(s,"py")==0){  //py�y�� 
            fgets(s,sizeof(door[doorNum].playerY),fp);
            door[doorNum].playerY = atol(s);
            //printf("door[%d].playerY=%d\n",doorNum,door[doorNum].playerY);
        }
    }
    doorNum++;
    fclose(fp);  
}

void playerDef(void){
    playerp = (Player*)malloc(sizeof(Player)); 
    playerp->hp = 100;
    strcpy(playerp->body,"��");
    playerp->speed = 1;
    playerp->state = STOP; 
}

void prepare(char* directName){
    char s[100]={0};  
    sprintf(s,"%s\\npc.txt",directName);
    setNpc(s);
    sprintf(s,"%s\\map.txt",directName);
    setMap(s); 
    sprintf(s,"%s\\door.txt",directName);
    setDoor(s);
}
